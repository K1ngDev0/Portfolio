<?php
// Config.php moet hier gebruikt worden voor de inlog gegeven dus verander de namen ~onki

$dbHost = 'localhost';
$dbName = 'project_database';
$dbUser = 'root';
$dbPass = '';

// $dbHost = 'rdbms.strato.de';
// $dbName = 'dbs12564961';
// $dbUser = 'dbu2898240';
// $dbPass = 'Larsje080307';


$base_url = 'http://localhost/Projecten%20pagina%20test/public/';