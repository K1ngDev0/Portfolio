<!DOCTYPE html>
<html lang="nl">

<?php
$id = $_GET['id'];
require_once("config/conn.php");
$query = "SELECT * FROM projecten WHERE id = :id";
$statement = $conn->prepare($query);
$statement->bindParam(':id', $id, PDO::PARAM_INT);
$statement->execute();
$project = $statement->fetch(PDO::FETCH_ASSOC);
?>

<?php require_once("head.php")?>
<head>
    <title>K1ngDev | <?php echo $project['name']; ?></title>
</head>
<body>
    <?php
        require_once("header.php");
        echo $project['name'];
        echo "<br />";
        echo $project['tekst_1'];
        echo "<br />";
        echo $project['tekst_2'];

        if ($project['gallary']) {
            $gallary = explode("|", $project['gallary']);
            $gallary = array_filter($gallary);
        }
    ?>

    <div class="gallary">
        <?php
        if ($project['gallary']) {
            foreach ($gallary as $image) {
                    echo '<div class="item">';
                    echo '<img src="' . $image . '" alt="Foto van het project">';
                    echo '</div>';
                }
        }
        ?>
    </div>
    <?php require_once("footer.php");?>
</body>
</html>