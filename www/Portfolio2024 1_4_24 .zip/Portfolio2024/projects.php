<!DOCTYPE html>
<html lang="nl">
<?php require_once("head.php")?>
<head>
    <title>K1ngDev | Projects</title>
</head>
<body>
    <?php 
        require_once("header.php");
        require_once("config/conn.php");
        $query = 'SELECT * From projecten';
        $statement = $conn->prepare($query);
        $statement->execute();
        $projecten = $statement->fetchAll(PDO::FETCH_ASSOC);
    ?>
    <div class="wrapper">
        <div class="projecten">
        <?php foreach ($projecten as $row): ?>
            <div class="item">
                    <img src="<?php echo $row ['thumbnail'];?>" alt="tumbnail projecten">
                    <button class="projectHolder">
                        <?php echo "<a href='singleProject.php?id={$row['id']}'>"?> 
                        <h2><?php echo $row ['name'];?></h2>
                    </button>
                </a>
            </div>
        <?php endforeach; ?>
        </div>
    </div>
    <?php require_once("footer.php");?>
</body>
</html>