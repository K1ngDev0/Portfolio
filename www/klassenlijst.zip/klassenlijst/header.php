<?php require_once 'backend/config.php'; ?>

<header>
    <div class="container">
        <nav>
            <a href="<?php echo $base_url; ?>/index.php">Home</a> |
            <a href="<?php echo $base_url; ?>/studenten/index.php">Studenten</a>
        </nav>
        <div>
            <a href="#" style="color: darkgrey;">Inloggen</a>
        </div>
    </div>
</header>
