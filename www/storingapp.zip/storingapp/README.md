# StoringApp

### Database
In de map `database` vind je het bestand `storingapp.sql`, deze kun je importeren in phpMyAdmin om de structuur van de database weg te zetten.

### Config
Kopieer voor je begint het bestand `config/config.example.php` en hernoem de kopie naar `config.php`. De echte config staat in je .gitignore, zodat je databasewachtwoord nooit online komt te staan.

![DeveloperLand](public_html/img/logo-big-fill-only.png)
