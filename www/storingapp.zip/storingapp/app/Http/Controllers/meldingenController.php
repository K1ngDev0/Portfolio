<?php

//Variabelen vullen
$attractie = $_POST['attractie'];
$type = $_POST['type'];
if(isset($_POST['prioriteit']))
{
    $prioriteit = 1;
}
else
{
    $prioriteit = 0;
};
$capaciteit = $_POST['capaciteit']; 
$melder = $_POST['melder'];
$overig = $_POST['overig'];

// echo $attractie . " / " . $capaciteit . " / " . $melder;

//1. Verbinding
require_once '../../../config/conn.php';

//2. Query

$query = "INSERT INTO meldingen (attractie, type, prioriteit, capaciteit, melder, overige_info)
VALUES(:attractie, :type, :prioriteit, :capaciteit, :melder, :overige_info)";

//3. Prepare

$statement = $conn->prepare($query);

$statement->execute([
    ":attractie" => $attractie,
    ":type" => $type,
    ":prioriteit" => $prioriteit,
    ":capaciteit" => $capaciteit,
    ":melder" => $melder,
    ":overige_info" => $overig,
]);

//4. Execute

$items = $statement->fetchAll(PDO::FETCH_ASSOC);

header("Location: ../../../resources/views/meldingen/index.php");