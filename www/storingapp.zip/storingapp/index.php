<!doctype html>
<html lang="nl">

<head>
    <title>StoringApp</title>
    <?php require_once 'resources/views/components/head.php'; ?>
</head>

<body>

    <?php require_once 'resources/views/components/header.php'; ?>

    <div class="container home">

        <h1>Welkom bij de technische dienst</h1>
        <img src="/public_html/img/logo-big-fill-only.png" alt="logo">

    </div>

</body>

</html>
