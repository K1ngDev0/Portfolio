<?php
    session_start();
?>

<!doctype html>
<html lang="nl">

<head>
    <title>Klassenlijst</title>
    <?php require_once 'head.php'; ?>
</head>

<body>

    <?php require_once 'header.php'; ?>
    
    <div class="container home">

        <h1>Klassenlijst WebApp</h1>
        <p>Extra oefeningen WDV-III</p>

    </div>

</body>

</html>
