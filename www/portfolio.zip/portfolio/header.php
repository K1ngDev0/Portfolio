<header>
    <div class="wrapper">
        <div class="wrapper-nav">
            <div class="wrapper-logo">
                <img src="img/logo.png" alt="logo">
                <h2>K1ngDev</h2>
            </div>
            <nav>
                <a href="index.php">Home</a>
                <a href="index.php">About</a>
                <a href="index.php">Projects</a>
                <a href="index.php">Contact</a>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5"/>
                </svg>
            </nav>   
        </div>
        <div class="wrapper-content">
            <h1>K1ng<span>Dev</span></h1>
        </div>
    </div>
</header>