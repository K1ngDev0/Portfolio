<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Mitr:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/4b73188074.js" crossorigin="anonymous"></script>
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/functions.js" defer></script>
</head>
    <body>
        <?php require_once("header.php")?>

        <main>
            <div class="wrapper">
                <div class="section1">
                    <h2 class="colored">Hey, I'm Lars Zijlmans</h2>
                    <h3 class="subColor">-K1ngDev</h3>
                    <div class="description">
                        <p>
                        <?php
                        $descriptionFile = fopen("information/description.txt", "r") or die("Unable to open file!");
                        echo fread($descriptionFile,filesize("information/description.txt"));
                        fclose($descriptionFile);
                        ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="wrapper">
                <div class="section2">
                    <h3 class="colored">Projects</h3>
                    <div class="project-cards">
                        <div class="card">
                            <div class="content">
                                <i class="fa-brands fa-itch-io fa-4x"></i>
                                <h4 class="colored">Game Development</h4>
                                <p>
                                <?php
                                    $gameDevFile = fopen("information/gameDev.txt", "r") or die("Unable to open file!");
                                    echo fread($gameDevFile,filesize("information/gameDev.txt"));
                                    fclose($gameDevFile);
                                ?>
                                </p>
                            </div>
                        </div>
                        <div class="card">
                            <div class="content">
                                <i class="fa-solid fa-file fa-4x"></i>
                                <h4 class="colored">Web Development</h4>
                                <p>
                                <?php
                                    $webDevFile = fopen("information/webDev.txt", "r") or die("Unable to open file!");
                                    echo fread($webDevFile,filesize("information/webDev.txt"));
                                    fclose($webDevFile);
                                ?>
                                </p>
                            </div>
                        </div>
                        <div class="card">
                            <div class="content">
                                <i class="fa-solid fa-code fa-4x"></i>
                                <h4 class="colored">Software Development</h4>
                                <p>
                                <?php
                                    $softDevFile = fopen("information/softDev.txt", "r") or die("Unable to open file!");
                                    echo fread($softDevFile,filesize("information/softDev.txt"));
                                    fclose($softDevFile);
                                ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php require_once("footer.php")?>
    </body>
</html>