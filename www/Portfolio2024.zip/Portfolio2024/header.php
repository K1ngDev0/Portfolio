<header class="myElement">
    <div class="header-wrapper">
        <div class="wrapper-logo">
            <img src="img/logo.png" alt="logo">
            <h2 class="colored">K1ngDev</h2>
        </div>
        <nav>
            <a href="index.php">Home</a>
            <a href="index.php">About</a>
            <a href="index.php">Projects</a>
            <a href="index.php">Contact</a>
        </nav>
        <!-- <div class="loginButtons">
            <button class="loginButton">Login</button>
        </div> -->
    </div>
</header>