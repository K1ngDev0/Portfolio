<!DOCTYPE html>
<html lang="nl">
<?php require_once("head.php")?>
<title>K1ngDev | About</title>
    <body>
        <?php require_once("header.php")?>

        <main>
            <div class="aboutWrapper">
                <h2 class="pageTitle colored">Over mij</h2>
                <div class="aboutContainer">
                    <div class="aboutInfo">
                        <p>
                            Mijn naam is Lars Zijlmans. Ik woon in Raamsdonksveer, Een klein dorpje in Noord-Brabant. Ik ben een 16-jarige software developer in opleiding. Ik heb een groot passie voor software development en ik wil daar ook mijn toekomst in bouwen. Ik hou van het programmeren van verschillende talen. 
                            <section id="GameDev">
                                <br><br><br>
                                <h3>Game Development</h3>
                                <br>
                                Ik begon software development sinds eind 2023. Daarvoor was ik ook al bezig met het maken van software, websites en games. Ik begon met programmeren/coderen zelf al sinds 2020. Mij leek het altijd erg leuk om games te ontwikkelen, dus toen besloot ik om games te gaan ontwikkelen. Ik begon er mee toen ik vakantie was. Nu ik er zelf over nadenk is dat best een aparte werkplek om te gaan coderen. Ik begon met tutorials van Godot. Het liefste wilde ik Unity gebruiken, maar ik had niet genoeg opslagruimte voor Unity. Ik heb een Godot gedaan en toen ben ik andere game engines gaan gebruiken. Zo heb ik onder andere Gamemaker Studio 2 en Construct 3.  Uiteindelijk ben ik Unity gaan gebruiken en daar startte echt de game development voor mij. Ik heb dat zo`n 2 jaar vol gehouden. Ik heb in die 2 jaar veel geleerd. Heel veel prototypes gemaakt en gepubliceerd. Meegedaan aan Game Jams en nieuwe mensen ontmoet. Eén iemand blijft toch altijd speciaal voor mij. Dat is mijn goede game development vriend <a href="https://ferrondw.000webhostapp.com/home" class="clickableText">Yakanashe</a>. We hebben elkaar hard gesteund en geholpen in onze development. Ik zal hem nooit vergeten.
                                <div class="mobileFoto">
                                    <div class="itchIo mobile">
                                        <img src="img/app-icon.png" alt="me">
                                    </div>
                                </div>
                            </section>    
                            <section id="WebDev">
                                <br><br><br>
                                <h3>Web Development</h3>
                                <br>
                                Uiteindelijk ben ik gestopt met game development vanwege te weinig motivatie ervoor. Ik had geen zin meer om door te gaan met game development en ben uiteindelijk gestopt met heel veel projecten die nog open stonden. Ik was toe aan iets nieuws. Als ik op school zat, zat ik vaak niet op te letten. Ik was veel drukker bezig met “inspecteren”. Het kijken naar de code van browsers. Ik snapte er nooit iets van, dus toen besloot ik een dag om uit te gaan vinden hoe ik nou eigenlijk websites maak. Ik dacht dat echt iets heel lastigs was, maar na een tijdje kwam ik erachter dat dat eigenlijk vrij simpel is. Ik begon met tutorials kijken en voor je het wist kon ik makkelijk omgaan met web development. Ik begon daar mee in 2022. Ik vond het zo leuk dat ik het nu het liefste doe. Ik hou van het ontwerpen en opmaken van die websites. Daarom dat mijn portfolio ook zoveel opmaak heeft. Ik wist nooit echt wat voor websites ik moest maken. Ik wou altijd al een portfolio, maar ik wist niet hoe ik moest beginnen. Nu dat ik de opleiding doe is het al een stuk makkelijker op te beginnen met een website. Het is natuurlijk nog steeds lastig om een website te bedenken, maar daar heb je natuurlijk je klant voor als je website gaat maken voor een bedrijf.
                            </section>
                            <section id="SoftDev">
                                <br><br><br>
                                <h3>Software Development</h3>
                                <br>
                                Ik heb tussen game- en web development ook nog software development gedaan. Wel een stuk minder dan game- en web development. Ik ben bijvoorbeeld een lange tijd bezig geweest met een Discord bot maken met python. Ik vind zelf python een erg leuke en makkelijke taal. Ik heb ook een aantal keer de programmeertaal Lua gebruikt. Ik vind dat een van de minste talen die er zijn. Ik heb het gebruikt voor het spel Roblox, maar ik vind het geen fijne programmeertaal om te gebruiken. C++ heb ik ook een korte tijd gebruikt, vanwege Arduino. Ik heb ook best wel wat elektronica thuis liggen en ik vind het ook erg leuk om ermee te experimenteren. C++ is ook een erg lastige taal om te begrijpen vind ik.
                            </section>
                            <br><br><br>
                            <h3>Mijn passie</h3>
                            <br>
                            Het liefste ben ik toch bezig met de front-end kant van development. Backend is ook nog wel leuk, maar daar liggen mijn interesses lager. Ik vind het leuk om te ontwerpen en ik heb daar meer ideeën voor. Ik vind het daarentegen wel interessant om een database op te bouwen en te gebruiken in het maken van websites waarbij je in moet loggen.
                            <br><br>
                            <div class="mobileFoto">
                                <div class="faceCircle mobile">
                                    <img src="img/meFoto.png" alt="me">
                                </div>
                            </div>
                            <br><br>    
                            <h3>Opleiding</h3>
                            <br>
                            Mijn opleiding heeft me zeker geholpen om meer interesse te hebben in development. Ik heb er tot nu toe ook veel geleerd en ervaring op gedaan. Ik heb verder kunnen leren en handige tips gekregen om mijn codering skills te kunnen verbeteren. Ik heb een erg goede tijd op deze opleiding en heb er zeker geen spijt van. 
                            Als je zelf interesse hebt in development zou ik ook zeker een soort gelijke opleiding doen om alles te verbeteren. Tips en handige informatie om alles nog beter en makkelijker te kunnen.
                            <br><br>
                            <a href="https://www.curio.nl/mbo/jouw-slimme-stad/softwaredeveloper/software-developer/?gad_source=1&gclid=CjwKCAiAivGuBhBEEiwAWiFmYaZSZW1vuGgU_DqovMGitDYAWb3Fpcmd8_91Un5hgpbYKc-V7XqBIxoCh-0QAvD_BwE" class="subColor clickableText">Curio Software Development - Breda</a>
                            <br><br><br>
                            <h3>Toekomst</h3>
                            <br>
                            Na deze opleiding zit ik erover na te denken om door te stromen naar het hbo. Het liefste ga ik da game development studeren, maar zit er nog erg over te twijfelen. Een andere optie dat ik in gedachten had was een zzp`er worden. Ik vind het fijn om thuis te werken in mijn eentje. Ik vind het erg lastig om in teams te werken, maar daar moet nog aan gewerkt worden. Momenteel werk ik in een supermarkt als een vulploeg medewerker. Nou is dat natuurlijk maar een bijbaantje, maar het liefste zou ik meer geld willen verdienen. Het leven gaat natuurlijk niet altijd om geld. Ik wil later ook zeker gewoon gezond in het leven staan en het gezellig kunnen hebben met vriendin en familie.
                            <br><br>
                            <span class="subColor">-K1ngDev, Lars Zijlmans</span> 
                        </p>
                    </div>
                    <div class="rightBlocks">
                        <div class="experienceBlock">
                            <div class="experienceInfo">
                                <h2 class="colored">Ervaringen</h2><br>
                                <h3 class="subColor">Development</h3>
                                <p>Game Development: ★★☆☆☆</p>
                                <p>Web Development: ★★★★☆</p>
                                <p>Software Development: ★★★☆☆</p>
                                <br><h3 class="subColor">Talen</h3>
                                <p>Nederlands: ★★★★☆</p>
                                <p>Engels: ★★★☆☆</p>
                                <p>Duits: ★☆☆☆☆</p>
                                <p class="experienceDesc subColor">- Mijn ervaringenworden elke dag steeds betervanwege mijn opleiding. Er zal altijd meer informatie bij komen,waardoor ik beter word.</p>
                            </div>
                        </div>
                        <div class="itchIo laptop">
                            <img src="img/app-icon.png" alt="itch">
                        </div>
                        <div class="faceCircle laptop">
                            <img src="img/meFoto.png" alt="Lars">
                        </div> 
                    </div>
                </div>
            </div>    
        </main>

        <?php require_once("footer.php")?>
    </body>
</html>